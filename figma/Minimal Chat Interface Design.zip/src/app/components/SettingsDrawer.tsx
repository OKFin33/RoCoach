import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Eye, EyeOff, X, AlertTriangle, ChevronDown, Server, Cloud, Cpu } from "lucide-react";

interface SettingsDrawerProps {
  open: boolean;
  onClose: () => void;
  personaLabel: string;
}

export function SettingsDrawer({ open, onClose, personaLabel }: SettingsDrawerProps) {
  const [apiKey, setApiKey] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [provider, setProvider] = useState("openai");
  const [model, setModel] = useState("gpt-4o");
  const [endpoint, setEndpoint] = useState("");
  const [localMode, setLocalMode] = useState(false);

  const inputStyle: React.CSSProperties = {
    width: "100%",
    background: "#FFFDF3",
    border: "2px solid rgba(23,23,23,0.18)",
    borderRadius: 10,
    padding: "9px 12px",
    fontSize: 13.5,
    color: "#171717",
    outline: "none",
    boxSizing: "border-box",
    fontFamily: "inherit",
  };

  const labelStyle: React.CSSProperties = {
    fontSize: 11.5,
    fontWeight: 700,
    color: "#2D2D2A",
    letterSpacing: "0.5px",
    textTransform: "uppercase",
    marginBottom: 5,
    display: "block",
  };

  const sectionStyle: React.CSSProperties = {
    marginBottom: 20,
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            style={{
              position: "absolute",
              inset: 0,
              background: "rgba(17,17,17,0.28)",
              zIndex: 40,
              backdropFilter: "blur(1px)",
            }}
          />

          {/* Drawer panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: "0%" }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 340, damping: 32 }}
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              bottom: 0,
              width: "88%",
              background: "#FFF8E8",
              border: "2.5px solid #171717",
              borderRight: "none",
              borderTopLeftRadius: 22,
              borderBottomLeftRadius: 22,
              zIndex: 45,
              overflowY: "auto",
              boxShadow: "0 18px 60px rgba(17,17,17,0.24)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {/* Header */}
            <div
              style={{
                padding: "18px 18px 14px",
                borderBottom: "2px solid rgba(23,23,23,0.12)",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: "#F7CF45",
                flexShrink: 0,
              }}
            >
              <div>
                <div
                  style={{
                    fontFamily: "'Nunito', sans-serif",
                    fontWeight: 900,
                    fontSize: 19,
                    color: "#171717",
                    letterSpacing: "-0.5px",
                  }}
                >
                  设置
                </div>
                <div style={{ fontSize: 11.5, color: "#2D2D2A", marginTop: 2, fontWeight: 600 }}>
                  当前人格：{personaLabel}
                </div>
              </div>
              <button
                onClick={onClose}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 999,
                  background: "#1A1A18",
                  border: "none",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <X size={15} color="white" strokeWidth={2.5} />
              </button>
            </div>

            {/* Content */}
            <div style={{ padding: "18px 18px", flex: 1 }}>
              {/* Security warning */}
              <div
                style={{
                  background: "rgba(216,137,46,0.10)",
                  border: "2px solid rgba(216,137,46,0.4)",
                  borderRadius: 10,
                  padding: "10px 12px",
                  marginBottom: 20,
                  display: "flex",
                  gap: 9,
                }}
              >
                <AlertTriangle size={15} color="#D8892E" style={{ flexShrink: 0, marginTop: 2 }} />
                <div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: "#D8892E", marginBottom: 3 }}>
                    API 密钥安全提示
                  </div>
                  <div style={{ fontSize: 11.5, color: "#5A4A2A", lineHeight: 1.5 }}>
                    你的 API Key 由你自己管理，仅限本次会话使用。请勿截图或粘贴到聊天中分享。
                  </div>
                </div>
              </div>

              {/* API Key */}
              <div style={sectionStyle}>
                <label style={labelStyle}>API 密钥</label>
                <div style={{ position: "relative" }}>
                  <input
                    type={revealed ? "text" : "password"}
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="sk-..."
                    style={{ ...inputStyle, paddingRight: 76 }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      right: 8,
                      top: "50%",
                      transform: "translateY(-50%)",
                      display: "flex",
                      gap: 4,
                    }}
                  >
                    <button
                      onClick={() => setRevealed((v) => !v)}
                      style={{
                        background: "none",
                        border: "none",
                        cursor: "pointer",
                        padding: 4,
                        color: "#2D2D2A",
                      }}
                    >
                      {revealed ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                    {apiKey && (
                      <button
                        onClick={() => setApiKey("")}
                        style={{
                          background: "none",
                          border: "none",
                          cursor: "pointer",
                          padding: 4,
                          color: "#B83A4B",
                        }}
                      >
                        <X size={14} />
                      </button>
                    )}
                  </div>
                </div>
                <div style={{ fontSize: 11, color: "#8A8070", marginTop: 5, lineHeight: 1.5 }}>
                  当前为内存存储，刷新后失效。
                </div>
              </div>

              {/* Provider */}
              <div style={sectionStyle}>
                <label style={labelStyle}>模型提供商</label>
                <div style={{ position: "relative" }}>
                  <select
                    value={provider}
                    onChange={(e) => setProvider(e.target.value)}
                    style={{
                      ...inputStyle,
                      appearance: "none",
                      paddingRight: 32,
                      cursor: "pointer",
                    }}
                  >
                    <option value="openai">OpenAI</option>
                    <option value="anthropic">Anthropic</option>
                    <option value="gemini">Google Gemini</option>
                    <option value="local">本地模型</option>
                  </select>
                  <ChevronDown
                    size={14}
                    color="#2D2D2A"
                    style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}
                  />
                </div>
              </div>

              {/* Model */}
              <div style={sectionStyle}>
                <label style={labelStyle}>模型</label>
                <input
                  type="text"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="gpt-4o"
                  style={inputStyle}
                />
              </div>

              {/* Endpoint */}
              <div style={sectionStyle}>
                <label style={labelStyle}>接入点（可选）</label>
                <input
                  type="text"
                  value={endpoint}
                  onChange={(e) => setEndpoint(e.target.value)}
                  placeholder="https://api.openai.com/v1"
                  style={inputStyle}
                />
              </div>

              {/* Local/Cloud mode */}
              <div
                style={{
                  ...sectionStyle,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  background: "#FFFDF3",
                  border: "2px solid rgba(23,23,23,0.15)",
                  borderRadius: 12,
                  padding: "12px 14px",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                  {localMode ? (
                    <Server size={16} color="#171717" />
                  ) : (
                    <Cloud size={16} color="#4B8FD8" />
                  )}
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#171717" }}>
                      {localMode ? "本地模式" : "云端模式"}
                    </div>
                    <div style={{ fontSize: 11, color: "#6A6A5A" }}>
                      {localMode ? "请求发送至本地服务" : "请求发送至云端 API"}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setLocalMode((v) => !v)}
                  style={{
                    width: 44,
                    height: 26,
                    borderRadius: 999,
                    background: localMode ? "#171717" : "#D8D2C2",
                    border: "2px solid #171717",
                    cursor: "pointer",
                    position: "relative",
                    transition: "background 0.2s",
                    flexShrink: 0,
                  }}
                >
                  <div
                    style={{
                      position: "absolute",
                      top: 2,
                      left: localMode ? 18 : 2,
                      width: 18,
                      height: 18,
                      borderRadius: 999,
                      background: localMode ? "#F7CF45" : "white",
                      transition: "left 0.2s",
                      boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                    }}
                  />
                </button>
              </div>

              {/* Current persona section */}
              <div
                style={{
                  background: "#FFFDF3",
                  border: "2px solid rgba(23,23,23,0.12)",
                  borderRadius: 12,
                  padding: "12px 14px",
                  marginBottom: 20,
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                  <Cpu size={14} color="#171717" />
                  <span style={{ fontSize: 12, fontWeight: 700, color: "#171717", textTransform: "uppercase", letterSpacing: "0.4px" }}>
                    当前人格
                  </span>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: "#171717" }}>{personaLabel}</div>
                <div style={{ fontSize: 11.5, color: "#6A6A5A", marginTop: 3 }}>
                  长按聊天头像可以切换人格
                </div>
              </div>

              {/* Save button */}
              <button
                style={{
                  width: "100%",
                  background: "#F7CF45",
                  border: "2.5px solid #171717",
                  borderRadius: 14,
                  padding: "12px 0",
                  fontSize: 15,
                  fontWeight: 800,
                  color: "#171717",
                  cursor: "pointer",
                  boxShadow: "0 4px 0 rgba(17,17,17,0.2)",
                  fontFamily: "'Nunito', sans-serif",
                }}
              >
                保存设置
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
