import React, { useRef, useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AgentAvatar, UserAvatar } from "./AgentAvatar";
import { ArtifactCard, ArtifactData } from "./ArtifactCard";
import { PersonaWheel, PersonaOption } from "./PersonaWheel";
import { SettingsDrawer } from "./SettingsDrawer";
import { PromptComposer } from "./PromptComposer";
import { RefreshCcw, AlertCircle } from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type MessageState = "sent" | "thinking" | "failed";

interface Message {
  id: string;
  role: "user" | "agent";
  text: string;
  state: MessageState;
  artifact?: ArtifactData;
  personaId?: string;
}

// ─── Personas ─────────────────────────────────────────────────────────────────

const PERSONAS: PersonaOption[] = [
  {
    id: "default",
    label: "Default",
    description: "API 默认",
    category: "default",
    availability: "available",
  },
  {
    id: "tactical_coach",
    label: "战术教练",
    description: "进攻压制与换手",
    category: "built_in",
    availability: "available",
    initials: "战",
    color: "#4B8FD8",
  },
  {
    id: "guide",
    label: "攻略向导",
    description: "新手友好路线",
    category: "built_in",
    availability: "available",
    initials: "攻",
    color: "#65B96A",
  },
  {
    id: "appraiser",
    label: "鉴定专家",
    description: "精灵评估与属性",
    category: "built_in",
    availability: "available",
    initials: "鉴",
    color: "#D8892E",
  },
  {
    id: "add",
    label: "添加人格",
    description: "Coming later",
    category: "add",
    availability: "placeholder",
  },
];

// ─── Mock initial messages ─────────────────────────────────────────────────────

const STRATEGY_ARTIFACT: ArtifactData = {
  type: "strategy",
  title: "策略摘要",
  rows: [
    {
      id: "r1",
      icon: "problem",
      label: "核心问题",
      body: "输出不足，缺乏稳定的收割点。",
    },
    {
      id: "r2",
      icon: "adjust",
      label: "推荐调整",
      body: "替换弱输出位，补充穿透与控场。",
    },
    {
      id: "r3",
      icon: "risk",
      label: "风险点",
      body: "面对高速先手队时容错较低。",
    },
  ],
  expandLabel: "查看详细分析",
};

const INITIAL_MESSAGES: Message[] = [
  {
    id: "m1",
    role: "agent",
    text: "我先帮你拆一下阵容思路。",
    state: "sent",
  },
  {
    id: "m2",
    role: "user",
    text: "这套队伍怎么优化？",
    state: "sent",
  },
  {
    id: "m3",
    role: "agent",
    text: "好的，这是我的分析结果：",
    state: "sent",
    artifact: STRATEGY_ARTIFACT,
  },
  {
    id: "m4",
    role: "user",
    text: "明白了，感谢！",
    state: "sent",
  },
  {
    id: "m5",
    role: "agent",
    text: "不客气，有问题随时来问我。",
    state: "sent",
  },
];

// ─── Prompt suggestion chips ──────────────────────────────────────────────────

const PROMPT_CHIPS = [
  "这套队伍先手够用吗？",
  "推荐我几只穿透系精灵",
  "对战火系队有没有克制？",
];

// ─── Subcomponents ────────────────────────────────────────────────────────────

function SessionDivider({ label }: { label: string }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "4px 0 8px",
      }}
    >
      <div style={{ flex: 1, height: 1, background: "rgba(23,23,23,0.10)" }} />
      <span
        style={{
          fontSize: 11,
          color: "#8A8070",
          fontWeight: 600,
          letterSpacing: "0.3px",
        }}
      >
        {label}
      </span>
      <div style={{ flex: 1, height: 1, background: "rgba(23,23,23,0.10)" }} />
    </div>
  );
}

function AgentBubble({
  message,
  thinking,
  onRetry,
}: {
  message: Message;
  thinking?: boolean;
  onRetry?: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 340, damping: 28 }}
      style={{ display: "flex", gap: 8, alignItems: "flex-end", maxWidth: "88%" }}
    >
      {/* Avatar anchor */}
      <AgentAvatar
        size={34}
        ringColor={thinking ? "blue" : "neutral"}
        thinking={thinking}
      />

      <div style={{ flex: 1 }}>
        {thinking ? (
          <div
            style={{
              background: "#FFFDF3",
              border: "2px solid rgba(23,23,23,0.18)",
              borderRadius: "16px 16px 16px 4px",
              padding: "10px 14px",
              display: "inline-flex",
              alignItems: "center",
              gap: 5,
              boxShadow: "0 2px 8px rgba(17,17,17,0.07)",
            }}
          >
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                animate={{ y: [0, -5, 0] }}
                transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.18 }}
                style={{
                  width: 7,
                  height: 7,
                  borderRadius: 999,
                  background: "#4B8FD8",
                }}
              />
            ))}
          </div>
        ) : message.state === "failed" ? (
          <div>
            <div
              style={{
                background: "#FFFDF3",
                border: "2px solid #B83A4B",
                borderRadius: "16px 16px 16px 4px",
                padding: "10px 14px",
                boxShadow: "0 2px 8px rgba(17,17,17,0.07)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  marginBottom: 4,
                }}
              >
                <AlertCircle size={13} color="#B83A4B" />
                <span
                  style={{ fontSize: 12, fontWeight: 700, color: "#B83A4B" }}
                >
                  回复失败
                </span>
              </div>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4A42",
                  margin: 0,
                  lineHeight: 1.5,
                }}
              >
                连接或模型请求出错，请重试。
              </p>
            </div>
            <button
              onClick={onRetry}
              style={{
                marginTop: 6,
                display: "flex",
                alignItems: "center",
                gap: 5,
                background: "#F7CF45",
                border: "2px solid #171717",
                borderRadius: 20,
                padding: "5px 12px",
                cursor: "pointer",
                fontSize: 12,
                fontWeight: 700,
                color: "#171717",
                boxShadow: "0 2px 0 rgba(17,17,17,0.2)",
              }}
            >
              <RefreshCcw size={11} strokeWidth={2.5} />
              重试
            </button>
          </div>
        ) : (
          <div>
            <div
              style={{
                background: "#FFFDF3",
                border: "2px solid rgba(23,23,23,0.2)",
                borderRadius: "16px 16px 16px 4px",
                padding: "10px 14px",
                boxShadow: "0 2px 8px rgba(17,17,17,0.07)",
              }}
            >
              <p
                style={{
                  fontSize: 15,
                  color: "#171717",
                  margin: 0,
                  lineHeight: "23px",
                }}
              >
                {message.text}
              </p>
            </div>
            {message.artifact && <ArtifactCard data={message.artifact} />}
          </div>
        )}
      </div>
    </motion.div>
  );
}

function UserBubble({ message }: { message: Message }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 340, damping: 28 }}
      style={{
        display: "flex",
        gap: 8,
        alignItems: "flex-end",
        justifyContent: "flex-end",
        maxWidth: "88%",
        alignSelf: "flex-end",
      }}
    >
      <div
        style={{
          background: "#F7CF45",
          border: "2px solid rgba(23,23,23,0.22)",
          borderRadius: "16px 16px 4px 16px",
          padding: "10px 14px",
          boxShadow: "0 2px 8px rgba(17,17,17,0.08)",
        }}
      >
        <p
          style={{
            fontSize: 15,
            color: "#171717",
            margin: 0,
            lineHeight: "23px",
          }}
        >
          {message.text}
        </p>
      </div>
      <UserAvatar size={30} />
    </motion.div>
  );
}

// ─── Suggestion chips (empty state) ──────────────────────────────────────────

function EmptyState({ onChip }: { onChip: (text: string) => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "32px 24px",
        gap: 20,
      }}
    >
      {/* Large agent avatar */}
      <AgentAvatar size={72} ringColor="yellow" />

      {/* Invite text */}
      <p
        style={{
          fontSize: 14.5,
          color: "#6A6A5A",
          textAlign: "center",
          margin: 0,
          lineHeight: 1.6,
          maxWidth: 200,
        }}
      >
        向 Roco 提问队伍策略、精灵搭配，或对战技巧
      </p>

      {/* Prompt chips */}
      <div style={{ display: "flex", flexDirection: "column", gap: 9, width: "100%" }}>
        {PROMPT_CHIPS.map((chip) => (
          <button
            key={chip}
            onClick={() => onChip(chip)}
            style={{
              background: "#FFFDF3",
              border: "2px solid rgba(23,23,23,0.2)",
              borderRadius: 20,
              padding: "9px 16px",
              fontSize: 13.5,
              color: "#2D2D2A",
              cursor: "pointer",
              textAlign: "left",
              fontFamily: "inherit",
              fontWeight: 500,
              boxShadow: "0 2px 0 rgba(17,17,17,0.1)",
              transition: "transform 0.1s",
            }}
            onMouseDown={(e) => (e.currentTarget.style.transform = "translateY(1px)")}
            onMouseUp={(e) => (e.currentTarget.style.transform = "translateY(0)")}
          >
            {chip}
          </button>
        ))}
      </div>
    </motion.div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export function ChatScreen() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [thinking, setThinking] = useState(false);
  const [wheelOpen, setWheelOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedPersonaId, setSelectedPersonaId] = useState("default");

  const scrollRef = useRef<HTMLDivElement>(null);

  const selectedPersona =
    PERSONAS.find((p) => p.id === selectedPersonaId) ?? PERSONAS[0];

  // Scroll to bottom whenever messages change
  useEffect(() => {
    const el = scrollRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages, thinking]);

  const handleSend = (text: string) => {
    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      text,
      state: "sent",
    };
    setMessages((prev) => [...prev, userMsg]);
    setThinking(true);

    // Simulate agent response
    setTimeout(() => {
      setThinking(false);
      const agentMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "agent",
        text: getMockReply(text),
        state: "sent",
      };
      setMessages((prev) => [...prev, agentMsg]);
    }, 1600 + Math.random() * 800);
  };

  const handleRetry = (id: string) => {
    setMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, state: "sent", text: "已重新获取，请稍候…" } : m))
    );
  };

  const handlePersonaSelect = (persona: PersonaOption) => {
    setSelectedPersonaId(persona.id);
    setWheelOpen(false);
  };

  const isEmpty = messages.length === 0;

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        background: "#F7CF45",
        display: "flex",
        flexDirection: "column",
        position: "relative",
        overflow: "hidden",
        fontFamily:
          "'Nunito', -apple-system, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif",
      }}
    >
      {/* ── Yellow background pattern ── */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `radial-gradient(circle, rgba(255,255,255,0.18) 1px, transparent 1px)`,
          backgroundSize: "22px 22px",
          pointerEvents: "none",
        }}
      />

      {/* ── Header ── */}
      <div
        style={{
          padding: "14px 16px 10px",
          display: "flex",
          alignItems: "center",
          gap: 10,
          flexShrink: 0,
          position: "relative",
          zIndex: 2,
        }}
      >
        <AgentAvatar
          size={44}
          ringColor={
            selectedPersonaId === "default"
              ? "neutral"
              : selectedPersonaId === "tactical_coach"
              ? "yellow"
              : "blue"
          }
          onLongPress={() => setWheelOpen(true)}
        />
        <div>
          <div
            style={{
              fontFamily: "'Nunito', sans-serif",
              fontWeight: 900,
              fontSize: 22,
              color: "#171717",
              letterSpacing: "-0.8px",
              lineHeight: 1,
            }}
          >
            Roco
          </div>
          {selectedPersonaId !== "default" && (
            <div
              style={{
                fontSize: 11,
                color: "#2D2D2A",
                fontWeight: 700,
                marginTop: 2,
                background: "rgba(23,23,23,0.09)",
                display: "inline-block",
                padding: "1px 7px",
                borderRadius: 20,
              }}
            >
              {selectedPersona.label}
            </div>
          )}
        </div>
      </div>

      {/* ── Chat sheet (cream paper) ── */}
      <div
        style={{
          flex: 1,
          margin: "0 10px",
          background: "#FFF8E8",
          border: "3px solid #171717",
          borderRadius: "20px 20px 0 0",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          position: "relative",
          zIndex: 2,
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.6)",
        }}
      >
        {/* Settings handle — right edge of chat sheet */}
        <button
          onClick={() => setDrawerOpen(true)}
          style={{
            position: "absolute",
            top: "50%",
            right: -3,
            transform: "translateY(-50%)",
            width: 20,
            height: 52,
            background: "#E8B92E",
            border: "3px solid #171717",
            borderLeft: "none",
            borderRadius: "0 10px 10px 0",
            cursor: "pointer",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 4,
            zIndex: 10,
            boxShadow: "3px 0 0 rgba(17,17,17,0.1)",
          }}
        >
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                width: 4,
                height: 4,
                borderRadius: 999,
                background: "#171717",
              }}
            />
          ))}
        </button>

        {/* Message scroll area */}
        <div
          ref={scrollRef}
          style={{
            flex: 1,
            overflowY: "auto",
            padding: "16px 14px 8px",
            display: "flex",
            flexDirection: "column",
            gap: 12,
          }}
        >
          {isEmpty ? (
            <EmptyState onChip={handleSend} />
          ) : (
            <>
              <SessionDivider label="今天" />

              {messages.map((msg) =>
                msg.role === "agent" ? (
                  <AgentBubble
                    key={msg.id}
                    message={msg}
                    onRetry={() => handleRetry(msg.id)}
                  />
                ) : (
                  <UserBubble key={msg.id} message={msg} />
                )
              )}

              {/* Thinking bubble */}
              <AnimatePresence>
                {thinking && (
                  <AgentBubble
                    key="thinking"
                    message={{ id: "thinking", role: "agent", text: "", state: "thinking" }}
                    thinking
                  />
                )}
              </AnimatePresence>
            </>
          )}
        </div>
      </div>

      {/* ── Composer ── */}
      <div style={{ position: "relative", zIndex: 2 }}>
        <PromptComposer onSend={handleSend} disabled={thinking} />
      </div>

      {/* ── Persona wheel overlay ── */}
      <div style={{ position: "absolute", inset: 0, zIndex: 50, pointerEvents: wheelOpen ? "auto" : "none" }}>
        <PersonaWheel
          open={wheelOpen}
          personas={PERSONAS}
          selectedId={selectedPersonaId}
          onSelect={handlePersonaSelect}
          onClose={() => setWheelOpen(false)}
        />
      </div>

      {/* ── Settings drawer ── */}
      <div style={{ position: "absolute", inset: 0, zIndex: 40, pointerEvents: drawerOpen ? "auto" : "none" }}>
        <SettingsDrawer
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          personaLabel={selectedPersona.label}
        />
      </div>
    </div>
  );
}

// ─── Mock reply helper ────────────────────────────────────────────────────────

function getMockReply(input: string): string {
  const lower = input.toLowerCase();
  if (lower.includes("穿透") || lower.includes("克制")) {
    return "水系和草系精灵对大部分火系队有不错的克制效果，同时可以搭配一只高速干扰位来压制先手。";
  }
  if (lower.includes("先手")) {
    return "先手压制的关键是让速度差达到 10 点以上，同时配置「快攻」技能链，让对方无法换场应对。";
  }
  if (lower.includes("感谢") || lower.includes("谢谢")) {
    return "不客气，随时来找我！有新的精灵数据也可以告诉我。";
  }
  return "明白，这个方向我来分析一下。你目前的阵容结构整体偏稳健，可以在输出端再做一些调整。";
}
