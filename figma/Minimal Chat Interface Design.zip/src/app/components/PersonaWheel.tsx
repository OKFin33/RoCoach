import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Plus } from "lucide-react";

export interface PersonaOption {
  id: string;
  label: string;
  description: string;
  category: "default" | "built_in" | "managed" | "add";
  availability: "available" | "unavailable" | "placeholder";
  initials?: string;
  color?: string;
}

interface PersonaWheelProps {
  open: boolean;
  personas: PersonaOption[];
  selectedId: string;
  onSelect: (persona: PersonaOption) => void;
  onClose: () => void;
}

const POSITIONS = [
  { angle: -90, label: "top" },    // 12 o'clock — Default
  { angle: -18, label: "ur" },     // 1:30
  { angle: 54,  label: "lr" },     // 4:30
  { angle: 126, label: "ll" },     // 7:30
  { angle: 198, label: "ul" },     // 10:30
];

const RADIUS = 100;

function toXY(angleDeg: number, r: number) {
  const rad = (angleDeg * Math.PI) / 180;
  return { x: Math.cos(rad) * r, y: Math.sin(rad) * r };
}

function MedallionAvatar({ persona, selected }: { persona: PersonaOption; selected: boolean }) {
  const size = 52;

  if (persona.category === "default") {
    return (
      <div
        style={{
          width: size,
          height: size,
          borderRadius: 999,
          background: "#1A1A18",
          border: selected ? "3px solid #F7CF45" : "2.5px solid #171717",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: selected
            ? "0 0 14px rgba(247,207,69,0.5), 0 4px 12px rgba(17,17,17,0.3)"
            : "0 4px 12px rgba(17,17,17,0.25)",
          position: "relative",
        }}
      >
        <svg viewBox="0 0 32 32" width={30} height={30}>
          <circle cx="16" cy="16" r="15" fill="#252520" />
          <ellipse cx="16" cy="17" rx="7" ry="6" fill="#1E1E1C" />
          <rect x="9" y="13.5" width="14" height="3.5" rx="1.75" fill="#111110" />
          <ellipse cx="13" cy="15.3" rx="1.6" ry="1.2" fill="#F7CF45" />
          <ellipse cx="19" cy="15.3" rx="1.6" ry="1.2" fill="#F7CF45" />
        </svg>
        {selected && (
          <div
            style={{
              position: "absolute",
              bottom: -2,
              right: -2,
              width: 16,
              height: 16,
              borderRadius: 999,
              background: "#F7CF45",
              border: "2px solid #171717",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
              <path d="M2 5 L4.2 7.2 L8 3" stroke="#171717" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        )}
      </div>
    );
  }

  if (persona.category === "add") {
    return (
      <div
        style={{
          width: size,
          height: size,
          borderRadius: 999,
          background: "rgba(255,248,232,0.5)",
          border: "2.5px dashed rgba(23,23,23,0.35)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 4px 12px rgba(17,17,17,0.12)",
        }}
      >
        <Plus size={20} color="rgba(23,23,23,0.45)" strokeWidth={2.5} />
      </div>
    );
  }

  const bgColor = persona.color || "#4B8FD8";
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 999,
        background: bgColor,
        border: selected ? "3px solid #F7CF45" : "2.5px solid #171717",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: selected
          ? "0 0 14px rgba(247,207,69,0.45), 0 4px 12px rgba(17,17,17,0.25)"
          : "0 4px 12px rgba(17,17,17,0.2)",
        position: "relative",
      }}
    >
      <span
        style={{
          fontFamily: "'Nunito', sans-serif",
          fontWeight: 900,
          fontSize: 18,
          color: "white",
          letterSpacing: "-1px",
        }}
      >
        {persona.initials}
      </span>
      {selected && (
        <div
          style={{
            position: "absolute",
            bottom: -2,
            right: -2,
            width: 16,
            height: 16,
            borderRadius: 999,
            background: "#F7CF45",
            border: "2px solid #171717",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
            <path d="M2 5 L4.2 7.2 L8 3" stroke="#171717" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      )}
    </div>
  );
}

export function PersonaWheel({
  open,
  personas,
  selectedId,
  onSelect,
  onClose,
}: PersonaWheelProps) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          onClick={onClose}
          style={{
            position: "absolute",
            inset: 0,
            background: "rgba(17,17,17,0.42)",
            zIndex: 50,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backdropFilter: "blur(2px)",
          }}
        >
          {/* Wheel container */}
          <div
            style={{ position: "relative", width: 280, height: 280 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Center label hint */}
            <div
              style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, calc(-50% - 90px))",
                background: "rgba(247,207,69,0.92)",
                border: "2px solid #171717",
                borderRadius: 20,
                padding: "4px 12px",
                fontSize: 11,
                fontWeight: 700,
                color: "#171717",
                whiteSpace: "nowrap",
                letterSpacing: "0.3px",
              }}
            >
              长按头像切换人格
            </div>

            {/* Medallions */}
            {personas.slice(0, 5).map((persona, i) => {
              const { x, y } = toXY(POSITIONS[i]?.angle ?? i * 72 - 90, RADIUS);
              const isSelected = persona.id === selectedId;

              return (
                <motion.div
                  key={persona.id}
                  initial={{ scale: 0, opacity: 0, x: 0, y: 0 }}
                  animate={{
                    scale: 1,
                    opacity: 1,
                    x: x - 26,
                    y: y - 26,
                  }}
                  exit={{ scale: 0, opacity: 0, x: 0, y: 0 }}
                  transition={{
                    type: "spring",
                    stiffness: 380,
                    damping: 26,
                    delay: i * 0.05,
                  }}
                  style={{
                    position: "absolute",
                    left: "50%",
                    top: "50%",
                    cursor: persona.availability === "placeholder" ? "default" : "pointer",
                  }}
                  onClick={() => {
                    if (persona.availability !== "placeholder") {
                      onSelect(persona);
                    }
                  }}
                >
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                    <MedallionAvatar persona={persona} selected={isSelected} />
                    <div
                      style={{
                        background: "rgba(255,248,232,0.95)",
                        border: "1.5px solid rgba(23,23,23,0.2)",
                        borderRadius: 20,
                        padding: "2px 8px",
                        fontSize: 10.5,
                        fontWeight: 700,
                        color: persona.category === "add" ? "rgba(23,23,23,0.4)" : "#171717",
                        whiteSpace: "nowrap",
                        boxShadow: "0 2px 6px rgba(17,17,17,0.1)",
                      }}
                    >
                      {persona.label}
                    </div>
                  </div>
                </motion.div>
              );
            })}

            {/* Center pulse ring */}
            <div
              style={{
                position: "absolute",
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
                width: 60,
                height: 60,
                borderRadius: 999,
                border: "3px solid #F7CF45",
                boxShadow: "0 0 18px rgba(247,207,69,0.45)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "#1A1A18",
              }}
            >
              <svg viewBox="0 0 32 32" width={42} height={42}>
                <circle cx="16" cy="16" r="15" fill="#252520" />
                <ellipse cx="16" cy="17" rx="7" ry="6" fill="#1E1E1C" />
                <rect x="9" y="13.5" width="14" height="3.5" rx="1.75" fill="#111110" />
                <ellipse cx="13" cy="15.3" rx="1.6" ry="1.2" fill="#F7CF45" />
                <ellipse cx="19" cy="15.3" rx="1.6" ry="1.2" fill="#F7CF45" />
              </svg>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
